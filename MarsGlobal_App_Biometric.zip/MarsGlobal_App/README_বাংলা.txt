MARS GLOBAL — বায়োমেট্রিক সহ APK বানানোর নিয়ম (ফোন থেকেই করা যায়)

১) github.com এ লগইন করে নতুন Repository খুলুন (নাম: mars-global, Private রাখুন)।
২) এই ZIP ফাইলটি ফোনে/পিসিতে Extract করুন। ভেতরের সব ফাইল ও ফোল্ডার (.github সহ) Repository-তে Upload করুন।
   * ফোনের ব্রাউজারে Upload করলে ".github" ফোল্ডার বাদ পড়তে পারে। তাই পিসির ব্রাউজার (Desktop site) ব্যবহার করুন, 
     অথবা Add file > Create new file এ গিয়ে নাম লিখুন  .github/workflows/build-apk.yml  এবং এই ফোল্ডারের ভেতরের build-apk.yml এর লেখা পেস্ট করুন।
৩) Repository-র "Actions" ট্যাবে যান → "Build APK" → "Run workflow"। প্রায় ৫–১০ মিনিট লাগবে।
৪) শেষ হলে সেই রানের নিচে "Artifacts" থেকে Mars_Global_APK ডাউনলোড করুন, জিপ খুলে app-debug.apk ইনস্টল করুন।

ব্যবহার:
- ফোনের Settings → Security থেকে আগে নিজের ফিঙ্গারপ্রিন্ট যোগ করুন।
- অ্যাপে পাসওয়ার্ড দিয়ে লগইন করুন → সেটিংস → লগইন → "বায়োমেট্রিক / ফিঙ্গারপ্রিন্ট লগইন" → চালু/বন্ধ।

গুরুত্বপূর্ণ:
- আগের APK (অন্য সাইনিং কী) আনইনস্টল করে নতুনটা ইনস্টল করতে হবে। ডিভাইসের localStorage ডেটা তখন মুছে যাবে, তাই আগে ব্যাকআপ নিন।
- এটা debug APK। Play Store-এ দিতে চাইলে আলাদা release সাইনিং লাগবে।
- appId: com.marsglobal.app
