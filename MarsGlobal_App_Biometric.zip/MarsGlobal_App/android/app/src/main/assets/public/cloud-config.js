/* MARS GLOBAL — ক্লাউড সিঙ্কের সংযোগ তথ্য
   Supabase থেকে পাওয়া দুটো মান ফাঁকা জায়গায় বসান।
   ফাঁকা থাকলে অ্যাপ আগের মতোই (শুধু ডিভাইসে) চলবে।
   ⚠ শুধু "anon public" key বসাবেন — "service_role" key কখনো নয়। */
window.MARS_CLOUD = {
  url: "",   // যেমন: "https://abcdxyz.supabase.co"
  key: ""    // যেমন: "eyJhbGciOi..." (anon public)
};
