/* ===== MARS: স্লো-মোশন (বিদ্যমান সব অ্যানিমেশন ধীর) =====
   আপনার CSS-এর কোনো সময় বদলানো হয়নি — ব্রাউজারের Web Animations API দিয়ে
   চলমান অ্যানিমেশন/ট্রানজিশনের গতি কমানো হয়।
   গতি বদলাতে শুধু নিচের F-এর সংখ্যা বদলান (1 = আগের মতো, 2 = ২ গুণ ধীর, 3 = ৩ গুণ ধীর)। */
(function(){
  var F=2;

  function slow(){
    if(!document.getAnimations) return;
    document.getAnimations().forEach(function(a){
      try{
        var ef=a.effect, tg=ef&&ef.target; if(!tg) return;
        if(tg.closest&&tg.closest("#introFx")) return;                  // ইন্ট্রো স্প্ল্যাশ বাদ
        if(ef.getComputedTiming().iterations===Infinity) return;        // অবিরাম লুপ (ভাসমান লোগো ইত্যাদি) বাদ
        if(a.__slow===F) return;
        a.playbackRate=1/F; a.__slow=F;
      }catch(e){}
    });
  }
  ["animationstart","transitionrun","transitionstart"].forEach(function(ev){ document.addEventListener(ev,slow,true); });
  ["click","touchend","mouseup"].forEach(function(ev){
    document.addEventListener(ev,function(){ requestAnimationFrame(function(){ slow(); requestAnimationFrame(slow); }); },true);
  });
})();
