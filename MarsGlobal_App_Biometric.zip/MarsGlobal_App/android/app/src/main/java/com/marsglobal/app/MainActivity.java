package com.marsglobal.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
